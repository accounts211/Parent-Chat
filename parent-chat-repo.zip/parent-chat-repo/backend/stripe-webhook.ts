// Supabase Edge Function: stripe-webhook
// Deploy via: Supabase Dashboard → Edge Functions → Create function → name it
// "stripe-webhook" → paste this in → Deploy.
//
// Then set these secrets (Dashboard → Edge Functions → stripe-webhook → Secrets,
// or Project Settings → Edge Functions → Secrets):
//   STRIPE_SECRET_KEY        (Stripe Dashboard → Developers → API keys)
//   STRIPE_WEBHOOK_SECRET    (created when you add the webhook endpoint below)
//   SUPABASE_URL             (Project Settings → API)
//   SUPABASE_SERVICE_ROLE_KEY (Project Settings → API — keep this secret, never
//                              put it in the frontend code)
//
// Then in Stripe Dashboard → Developers → Webhooks → Add endpoint, use:
//   https://<your-project-ref>.functions.supabase.co/stripe-webhook
// and select the "checkout.session.completed" event.

import Stripe from "npm:stripe@14";
import { createClient } from "npm:@supabase/supabase-js@2";

const stripe = new Stripe(Deno.env.get("STRIPE_SECRET_KEY")!, {
  apiVersion: "2023-10-16",
});
const webhookSecret = Deno.env.get("STRIPE_WEBHOOK_SECRET")!;

const supabase = createClient(
  Deno.env.get("SUPABASE_URL")!,
  Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
);

Deno.serve(async (req) => {
  const signature = req.headers.get("Stripe-Signature");
  const body = await req.text();

  let event: Stripe.Event;
  try {
    event = await stripe.webhooks.constructEventAsync(body, signature!, webhookSecret);
  } catch (err) {
    console.error("Signature verification failed:", err.message);
    return new Response(`Webhook Error: ${err.message}`, { status: 400 });
  }

  if (event.type === "checkout.session.completed") {
    const session = event.data.object as Stripe.Checkout.Session;
    const email = (session.customer_details?.email || session.customer_email || "").toLowerCase();

    if (email) {
      const { error } = await supabase
        .from("members")
        .update({ premium: true, premium_since: new Date().toISOString() })
        .eq("email", email);

      if (error) console.error("Failed to upgrade member:", error.message);
    }
  }

  // Handle cancellations so premium can be turned off too
  if (event.type === "customer.subscription.deleted") {
    const sub = event.data.object as Stripe.Subscription;
    const customer = await stripe.customers.retrieve(sub.customer as string);
    const email = ((customer as Stripe.Customer).email || "").toLowerCase();
    if (email) {
      await supabase.from("members").update({ premium: false }).eq("email", email);
    }
  }

  return new Response("ok", { status: 200 });
});
